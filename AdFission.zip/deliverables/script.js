/* =========================================================
   AdFission Agent · 广告素材裂变 Demo（纯前端模拟）
   ---------------------------------------------------------
   交互：
   1) 点击「运行裂变」→ 2s 加载动画 → 随机生成 6 张素材卡
   2) 每张卡：emoji 占位图 / 随机策略标签 / 3-5 星随机评分
   3) 点击卡片 → Modal 展示「创意说明」
   4) 下拉框按策略标签过滤
   5) 「导出选中」→ 提示已导出 N 个素材
   ========================================================= */

/* ---------- 策略标签预设池 ---------- */
const TAG_POOL = [
  {
    key: 'function', label: '突出功能', emoji: '🎧',
    title: '功能旗舰版', accent: '#22d3ee',
    briefs: [
      '双馈降噪直达痛点，硬核参数一目了然',
      '40dB 降噪深潜体验，把安静做成核心卖点',
    ],
    explain: '本版本聚焦产品「主动降噪」的核心功能，通过数据锚点与卖点放大建立功能信任，直击对噪音敏感、追求沉浸体验的用户痛点，帮助理性用户快速做出购买决策。',
    audience: '适合注重功能参数的理性决策用户，建议投放 3C 数码垂类与测评类内容流量。',
  },
  {
    key: 'price', label: '突出价格', emoji: '💰',
    title: '价格钩子版', accent: '#fb923c',
    briefs: [
      '限时直降 ¥200，价格冲击先声夺人',
      '用高性价比撬动价格敏感人群的即时决策',
    ],
    explain: '本版本以「到手价 ¥299」与划线价形成对比锚点，放大优惠力度、弱化决策成本，用价格钩子促进点击与转化，突出产品性价比优势。',
    audience: '适合价格敏感型用户与促销节点，投放电商信息流与返利类渠道效果更佳。',
  },
  {
    key: 'look', label: '突出颜值', emoji: '✨',
    title: '颜值种草版', accent: '#f472b6',
    briefs: [
      '把颜值做成第一眼记忆点，出街即种草',
      '流光质感主视觉，唤醒审美种草冲动',
    ],
    explain: '本版本强化产品外观设计语言与潮流质感，以视觉美感建立第一印象，通过「戴上即焦点」的社交想象驱动种草与分享，满足用户对美与表达自我的需求。',
    audience: '适合颜值驱动、追求潮流的年轻用户，适合小红书图文与短视频种草场景。',
  },
  {
    key: 'scene', label: '场景化', emoji: '🏙️',
    title: '通勤场景版', accent: '#60a5fa',
    briefs: [
      '早高峰地铁里，留一块安静频道',
      '把通勤痛点搬进画面，一秒带入使用场景',
    ],
    explain: '本版本将产品置入通勤等真实生活场景，用情境代入唤起「我也需要」的共鸣，把抽象的功能点转化为可感知的生活改善，拉近品牌与用户的距离。',
    audience: '适合通勤族与高频移动人群，建议叠加通勤时段与本地生活流量池投放。',
  },
  {
    key: 'persona', label: '人群圈定', emoji: '🎓',
    title: '学生人群版', accent: '#34d399',
    briefs: [
      '备考 / 网课 / 通勤，一刷静音',
      '为学生党圈定语境，免息分期降低门槛',
    ],
    explain: '本版本锁定学生人群的学习与生活语境，用「备考、网课」等高共鸣场景拉近距离，并以白条免息等权益降低决策门槛，精准承接该人群的真实需求。',
    audience: '适合学生与职场新人，建议配合校园流量及教育学习类内容定向包投放。',
  },
  {
    key: 'urgent', label: '限时紧迫', emoji: '⏰',
    title: '首销倒计时版', accent: '#f43f5e',
    briefs: [
      '首销 3 天专属价，过时不候',
      '限时 + 稀缺双钩子，刺激即刻下单',
    ],
    explain: '本版本以「首销仅 3 天」制造时间稀缺感，配合限量赠品强化紧迫氛围，通过倒计时元素刺激用户在小窗口期内快速决策，适合抢量与新品冷启动。',
    audience: '适合大促抢量与新品首发，投放信息流时建议叠加站内秒杀氛围元素。',
  },
];

/* ---------- 工具 ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

function starsHTML(score) {
  const on = '<span class="on">' + '★'.repeat(score) + '</span>';
  const off = '<span class="off">' + '☆'.repeat(5 - score) + '</span>';
  return `<span class="stars">${on}${off}<em>${score}.0</em></span>`;
}

/* ---------- 状态 ---------- */
let currentResults = []; // { id, meta, score, brief }
let running = false;

/* ---------- 流水线步骤 ---------- */
function setStep(n) {
  $$('.pipeline .step').forEach((el, i) => {
    el.classList.remove('done', 'active');
    if (!n) return;
    if (i + 1 < n) el.classList.add('done');
    else if (i + 1 === n) el.classList.add('active');
  });
}

/* ---------- 选中 / 导出计数 ---------- */
function isSelected(idx) {
  return $('.v-card[data-idx="' + idx + '"]')?.classList.contains('sel') || false;
}
function updateSelCounter() {
  const n = $$('.v-card.sel').length;
  $('#selCounter').innerHTML = `已选 <b>${n}</b> / 6`;
}
function setCardSelected(idx, on) {
  const card = $('.v-card[data-idx="' + idx + '"]');
  if (!card) return;
  card.classList.toggle('sel', on);
  const selBtn = card.querySelector('.v-select');
  if (selBtn) selBtn.classList.toggle('on', on);
  updateSelCounter();
}

/* ---------- 构建卡片 ---------- */
function buildCard(item, delay) {
  const m = item.meta;
  const card = document.createElement('article');
  card.className = 'v-card';
  card.dataset.idx = item.idx;
  card.dataset.key = m.key;
  card.style.setProperty('--acc', m.accent);
  card.style.setProperty('--tint', hexA(m.accent, 0.14));
  card.style.setProperty('--glow', hexA(m.accent, 0.55));
  card.style.setProperty('--thumb-from', hexA(m.accent, 0.16));

  card.innerHTML = `
    <div class="v-thumb">
      <span class="v-emoji">${m.emoji}</span>
      <span class="v-no">V${item.idx + 1}</span>
      <button class="v-select" type="button" aria-label="选择加入导出" data-act="select"><span class="tick">✓</span></button>
    </div>
    <div class="v-meta">
      <div class="m-row">
        <span class="tag-chip">${m.label}</span>
        ${starsHTML(item.score)}
      </div>
      <p class="v-brief">${item.brief}</p>
      <div class="v-hint">点击卡片查看<b> 创意说明 </b>→</div>
    </div>
  `;
  return card;
}

function hexA(hex, alpha) {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/* ---------- 运行裂变 ---------- */
async function runFission() {
  if (running) return;
  running = true;

  const btn = $('#runBtn');
  btn.disabled = true;

  // 关闭可能打开的弹窗 / 重置筛选
  closeModal();
  $('#tagFilter').value = 'all';

  const grid = $('#variantGrid');
  grid.innerHTML = '';
  setStep(0);
  updateSelCounter();
  $('#countDone').textContent = 0;
  $('#costTime').textContent = '--';

  // 1) 加载动画（约 2s），同时流水线推进
  grid.innerHTML = `
    <div class="load-panel">
      <div class="load-ring"></div>
      <div class="load-title">Agent 正在裂变生成素材<span class="dots"></span></div>
      <div class="load-sub">STRATEGY · COPY · IMAGE · QA</div>
      <div class="load-bar"><i></i></div>
    </div>
  `;

  const t0 = performance.now();
  await wait(620); setStep(1);   // 策略路由
  await wait(680); setStep(2);   // 文案重写
  await wait(700); setStep(3);   // 图像生成（累计 ≈ 2s）

  // 2) 随机生成 6 个版本：策略标签打乱分配 + 3-5 星随机 + 文案随机
  const metas = shuffle(TAG_POOL);
  currentResults = metas.map((meta, idx) => ({
    idx,
    meta,
    score: randInt(3, 5),
    brief: pick(meta.briefs),
  }));

  // 3) 渲染卡片
  grid.innerHTML = '';
  const cards = currentResults.map((item) => buildCard(item, item.idx * 110));
  cards.forEach((c) => grid.appendChild(c));

  // 卡片逐个浮现
  for (let i = 0; i < cards.length; i++) {
    await wait(120);
    cards[i].classList.add('show');
    $('#countDone').textContent = i + 1;
  }

  // 4) 质量评测完成
  await wait(200); setStep(4);
  await wait(500); setStep(5);

  const cost = ((performance.now() - t0) / 1000).toFixed(1);
  $('#costTime').textContent = cost + ' s';

  btn.disabled = false;
  running = false;
}

/* ---------- Modal：创意说明 ---------- */
function openModal(idx) {
  const item = currentResults[idx];
  if (!item) return;
  const m = item.meta;

  closeModal();
  const mask = document.createElement('div');
  mask.className = 'modal-mask';

  const sel = isSelected(idx);
  mask.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true">
      <div class="modal-hero">
        <span class="m-emoji">${m.emoji}</span>
        <span class="m-no">V${idx + 1} · ${m.label}策略</span>
      </div>
      <div class="modal-body">
        <div class="modal-head">
          <h3>${m.title} <span class="tag-chip">${m.label}</span></h3>
          ${starsHTML(item.score)}
        </div>
        <div class="m-label">Creative Brief · 创意说明</div>
        <p class="m-explain">${m.explain}</p>
        <div class="m-audience">🎯 <b>受众建议：</b>${m.audience}</div>
        <div class="m-hint">
          <span class="score-chip">质检 ${item.score}.0 ★</span>
          ${scoreAdvice(item.score)}
        </div>
        <div class="modal-actions">
          <button class="btn ghost" type="button" data-act="close">关闭</button>
          <button class="btn primary ${sel ? 'on' : ''}" type="button" data-act="toggle-sel">
            ${sel ? '✓ 已加入导出（点击取消）' : '加入导出'}
          </button>
        </div>
      </div>
    </div>
  `;
  mask.dataset.idx = idx;
  document.body.appendChild(mask);

  requestAnimationFrame(() => mask.classList.add('show'));
}

function closeModal() {
  const mask = $('.modal-mask');
  if (!mask) return;
  mask.classList.remove('show');
  setTimeout(() => mask.remove(), 220);
}

function scoreAdvice(score) {
  if (score >= 4) return '质检评分优秀，画面与文案协同度高，建议进入 A/B 测试并优先分配预算。';
  return '质检评分达标但记忆点一般，建议优化主视觉与首屏文案后再小流量试投。';
}

/* ---------- Toast ---------- */
let toastTimer = null;
function showToast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2000);
}

/* ---------- 事件绑定 ---------- */
function bindEvents() {
  // 运行裂变
  $('#runBtn').addEventListener('click', runFission);

  // 下拉筛选
  $('#tagFilter').addEventListener('change', (e) => {
    const key = e.target.value;
    $$('#variantGrid .v-card').forEach((c) => {
      const show = key === 'all' || c.dataset.key === key;
      c.style.display = show ? '' : 'none';
    });
  });

  // 网格事件委托：点击卡片 → 创意说明；点选择钮 → 加入导出
  $('#variantGrid').addEventListener('click', (e) => {
    const selBtn = e.target.closest('.v-select');
    const card = e.target.closest('.v-card');
    if (!card) return;
    const idx = Number(card.dataset.idx);
    if (selBtn) {
      e.stopPropagation();
      setCardSelected(idx, !card.classList.contains('sel'));
      return;
    }
    openModal(idx);
  });

  // 导出选中
  $('#exportBtn').addEventListener('click', () => {
    const n = $$('.v-card.sel').length;
    if (n === 0) {
      showToast('请先勾选需要导出的素材（点击卡片右上角圆圈）');
      return;
    }
    showToast(`已导出 ${n} 个素材（模拟，含策略标签与评分元数据）`);
  });

  // Modal 操作 / Esc / 遮罩点击
  document.addEventListener('click', (e) => {
    const mask = e.target.closest('.modal-mask');
    if (!mask) return;
    const actBtn = e.target.closest('[data-act]');
    const idx = Number(mask.dataset.idx);

    if (e.target === mask) {           // 点遮罩关闭
      closeModal();
    } else if (actBtn?.dataset.act === 'close') {
      closeModal();
    } else if (actBtn?.dataset.act === 'toggle-sel') {
      const on = !isSelected(idx);
      setCardSelected(idx, on);
      actBtn.classList.toggle('on', on);
      actBtn.textContent = on ? '✓ 已加入导出（点击取消）' : '加入导出';
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });
}

/* ---------- 启动：首屏自动运行一次 ---------- */
document.addEventListener('DOMContentLoaded', () => {
  bindEvents();
  setTimeout(runFission, 300);
});
